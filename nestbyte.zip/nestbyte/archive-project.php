<?php

/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Santoi
 */

get_header();
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';

?>
    <!-- Bredcrumb Start -->
    <section class="nb_bredcrumb nb-bg1">
        <div class="nb_bredcrumb_wrapper">
            <div class="container">
                <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                    <div class="nb_bredcrumb_left">
                        <div class="nb-about-contain">
                            <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                                <?php
                                //                                echo "<pre>";
                                //                                print_r(roots_title());
                                //                                echo"</pre>";
                                nestbyte_breadcrumbs_left();
                                ?>
                            </h4>
                        </div>
                    </div>
                    <div class="nb_bredcrumb_right">
                        <div>
                            <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                                <?php if (is_archive()) {
                                    nestbyte_breadcrumbs();
                                } else {
                                    ?>
                                    <a href="#" class="nb-ahbr">Home</a>
                                    <span>/</span>
                                    <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                                <?php } ?>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Bredcrumb End -->

    <!-- Project section Start-->
    <section class="nbv2_project nb-bg1 nb-pb146 pb-30 nb-malls ">
        <div class="nbv2_project_wrapper">
            <div class="container">
                <div class="nbv2_project_wrapper nb-pt61">
                    <div class="nbv2_project_wrapper_main">
                        <div class="row">
                            <?php if (have_posts()) : ?>
                                <?php
                                /* Start the Loop */
                                while (have_posts()) :
                                    the_post();

                                    /*
                                    * Include the Post-Type-specific template for the content.
                                    * If you want to override this in a child theme, then include a file
                                    * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                                    */
                                    get_template_part('template-parts/content', 'project');

                                endwhile;

                                nestbyte_page_navs();

                            else :

                                get_template_part('template-parts/content', 'none');

                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Project section End-->

<?php
get_footer();