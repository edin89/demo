<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Nestbyte
 */

get_header();
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';
$page_meta = get_post_meta(get_the_ID(), 'nestbyte_page_options', true);
$page_width = (!empty($page_meta['page_width'])) ? $page_meta['page_width'] : 'container';
$breadcrumb = !empty($page_meta['page_breadcrumb']) ? $page_meta['page_breadcrumb'] : '';

?>
    <?php if ($breadcrumb== true){ ?>
      
    <?php } else {  ?>
      <!-- Page breadcrumb Start -->
        <section class="nb_bredcrumb nb-bg1">
        <div class="nb_bredcrumb_wrapper">
            <div class="container">
                <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                    <div class="nb_bredcrumb_left">
                        <div class="nb-about-contain">
                            <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                                <?php
                                
                                nestbyte_breadcrumbs_left();
                                ?>
                            </h4>
                        </div>
                    </div>
                    <div class="nb_bredcrumb_right">
                        <div>
                            <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                                <?php if (is_archive()) {
                                    nestbyte_breadcrumbs();
                                } else {
                                    ?>
                                    <a href="#" class="nb-ahbr">Home</a>
                                    <span>/</span>
                                    <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                                <?php } ?>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php } ?>
    <main id="primary" class="site-main">
        <div class="<?php echo esc_attr($page_width); ?>">

            <?php
            while (have_posts()) :
                the_post();

                get_template_part('template-parts/content', 'page');

                // If comments are open or we have at least one comment, load up the comment template.
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif;

            endwhile; // End of the loop.
            ?>
        </div>

    </main><!-- #main -->

<?php
get_footer();
