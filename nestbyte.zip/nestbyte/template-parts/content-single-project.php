<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Santoi
 */
$project_taxonomy = 'project-category';
$project_taxonomy_array = get_terms($project_taxonomy);
$related_project_subtitle = get_post_meta(get_the_ID(), 'related_project_subtitle', true);
$related_project_switcher = cs_get_option('prelated_project_on_off');
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';
?>
<!-- Bredcrumb Start -->
<section class="nb_bredcrumb nb-bg1">
    <div class="nb_bredcrumb_wrapper">
        <div class="container">
            <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                <div class="nb_bredcrumb_left">
                    <div class="nb-about-contain">
                        <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                            <?php
                            nestbyte_breadcrumbs_left();
                            ?>
                        </h4>
                    </div>
                </div>
                <div class="nb_bredcrumb_right">
                    <div>
                        <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                            <?php if (is_archive()) {
                                nestbyte_breadcrumbs();
                            } else {
                                ?>
                                <a href="#" class="nb-ahbr">Home</a>
                                <span>/</span>
                                <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                            <?php } ?>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bredcrumb End -->

<!-- nb-project_details-area start  -->
<section class="nb-project_details-area nb-bg1 nb-malls nb__mobile-pt-100">
    <div class="container">
        <div class="row g-30">
            <?php if (has_post_thumbnail()) : ?>
                <div class="col-12 col-md-7">
                    <div class="nb-project_details-img">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </div>
            <?php endif; ?>


            <div class="col-12 col-md-5">
                <div class="nb-project_details-contain">
                    <h4 class="nb-project_details-contain-h4 position-relative has_char_anim">
                        <?php the_title(); ?>
                    </h4>
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- nb-project_details-area End -->

<?php
if ($related_project_switcher){
$categories = get_the_terms('', 'project-category');

if ($categories) {
    $category_ids = array();
    foreach ($categories as $category) {
        $category_ids[] = $category->term_id;

    }

    // Query for related posts
    $args = array(
        'post_type' => 'project',
        'post__not_in' => array(get_the_ID()),
        'posts_per_page' => 2,
        'tax_query' => array(
            array(
                'taxonomy' => 'project-category',
                'field' => 'term_id',
                'terms' => $category_ids,
            )
        )
    );

    $related_posts_query = new WP_Query($args);

    // Display related posts
    if ($related_posts_query->have_posts()) {
        ?>
        <!-- nb-Related-area start  -->
        <section class="nb-Related-area nb-bg1 nb__mobile-pb-100">
            <div class="container">
                <div>
                    <h4 class="nb-Related-contain-h4 has_char_anim">
                        <?php _e('Related Project', 'nestbyte'); ?>
                    </h4>
                </div>
                <div class="row g-30">
                    <?php
                    while ($related_posts_query->have_posts()) {
                        $related_posts_query->the_post();
                        ?>
                        <div class="col-12 col-md-6 nb-Related-box-col has_fade_anim">
                            <div class="nb-Related-box">
                                <div class="nb-Related-box-img">
                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="nb-Related-1.png">
                                </div>

                                <div class="nb-Related-box-contain">
                                    <h4>
                                        <a href="<?php the_permalink(); ?>" class="nb_animation_title_main">
                                            <span class="nb_animation_title_main_non"><?php the_title(); ?></span>
                                            <span class="nb_animation_title_main_hbr"><?php the_title(); ?></span>
                                        </a>
                                    </h4>
                                    <?php
                                    if (!empty($related_project_subtitle) ) { ?>
                                        <h6 class="nb-ahbr">
                                            <?php echo esc_html($related_project_subtitle); ?>
                                        </h6>
                                    <?php }
                                    ?>
                                    <?php the_excerpt(); ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </section>
        <!-- nb-Related-area End -->
        <?php
    }
}
}
?>






