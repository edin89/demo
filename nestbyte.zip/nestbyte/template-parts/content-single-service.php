<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Santoi
 */
$service_taxonomy = 'Services-category';
$service_taxonomy_array = get_terms($service_taxonomy);
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';
?>
<!-- Bredcrumb Start -->
<section class="nb_bredcrumb nb-bg1">
    <div class="nb_bredcrumb_wrapper">
        <div class="container">
            <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                <div class="nb_bredcrumb_left">
                    <div class="nb-about-contain">
                        <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                            <?php
                            nestbyte_breadcrumbs_left();
                            ?>
                        </h4>
                    </div>
                </div>
                <div class="nb_bredcrumb_right">
                    <div>
                        <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                            <?php if (is_archive()) {
                                nestbyte_breadcrumbs();
                            } else {
                                ?>
                                <a href="#" class="nb-ahbr">Home</a>
                                <span>/</span>
                                <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                            <?php } ?>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bredcrumb End -->
<!-- nb-service-info-area start  -->
<section class="nb-service-info-area nb-bg1">
    <div class="container nb-service-info-container">
        <div class="row">
            <div class="col-12  col-md-8">
                <?php
                if (has_post_thumbnail()) : ?>
                    <div class="nb-service-info-contain-img">
                        <?php the_post_thumbnail(); ?>
                    </div>
                <?php endif; ?>

                <div class="nb-service-info-contain">

                    <div class="nb-service-info-contain-box1">
                        <h6 class="has_text_reveal_anim">
                            <?php

                            foreach ($service_taxonomy_array as $service_taxonomy_item) {
                                ?>
                                <a class="nb-f16 nb-fw4 nb-bcl nb-ffb text-capitalize service-cat"
                                   href="<?php echo esc_attr(get_term_link($service_taxonomy_item, $service_taxonomy_array)); ?>">
                                    <span><?php echo esc_html($service_taxonomy_item->name); ?> <span
                                                class="last-cat">,</span></span>

                                </a>
                                <?php
                            }

                            ?>
                        </h6>
                        <h4 class="has_char_anim">
                            <?php the_title(); ?>
                        </h4>
                    </div>
                    <div class="has_fade_anim nb-wcl">
                        <?php the_content(); ?>
                    </div>

                </div>

            </div>

            <div class="col-12  col-md-4">
                <div>

                    <?php
                        if (is_active_sidebar('service-sidebar-1')){
                            dynamic_sidebar( 'service-sidebar-1' );
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- nb-service-info-area End -->
