<?php
$copyright_btn_switcher = cs_get_option('footer_copyright_enable');
$copyright_text = cs_get_option('copyright_text');
$footer_item_list = cs_get_option('footer_item_list');

?>
<!-- Footer Start  -->
<footer class="home__two-footer">
    <div class="nb__footer-start">
        <div class="container">
            <div class="d-flex nb__footer-widget-box pb-80 flex-wrap flex-lg-nowrap">
                <?php if (is_active_sidebar('nestbyte_about_widget_home_two')) { ?>
                    <div class="nb__foter-about pera-content has_fade_anim">
                        <?php dynamic_sidebar('nestbyte_about_widget_home_two'); ?>
                    </div>
                <?php } ?>
                <?php if (is_active_sidebar('nestbyte_useful_link_home_two')) { ?>
                    <div class="nb__usefull-link-item pl-35 has_fade_anim">
                        <?php dynamic_sidebar('nestbyte_useful_link_home_two'); ?>
                    </div>
                <?php } ?>
                <?php if (is_active_sidebar('nestbyte_useful_link_home_two_style_two')) { ?>
                    <div class="nb__usefull-link-item pl-65 nb__widget-contact has_fade_anim">
                        <?php dynamic_sidebar('nestbyte_useful_link_home_two_style_two'); ?>
                    </div>
                <?php } ?>
                <?php if (is_active_sidebar('nestbyte_social_icon_home_two')) { ?>
                    <div class="nb__footer-newsletter pl-65 pera-content has_fade_anim">
                        <?php dynamic_sidebar('nestbyte_social_icon_home_two'); ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="nb__copyright-section pt-30 pb-30">
        <div class="container d-flex justify-content-between flex-wrap gap-2">
            <?php if ($copyright_btn_switcher) { ?>
                <div class="nb__copyright-text pera-content">
                    <p><?php echo wp_kses($copyright_text, true); ?></p>
                </div>
            <?php } ?>
            <div class="nb__footer-nav-link">
                <ul class="m-0 p-0 list-unstyled d-flex">
                    <?php
                    if (is_array($footer_item_list)) {
                        foreach ($footer_item_list as $item) {
                            ?>
                            <li><a href="<?php echo esc_url($item['footer_list_link']['url']); ?>"><?php echo esc_html($item['footer_list_text']); ?></a></li>
                            <?php
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- Footer End  -->