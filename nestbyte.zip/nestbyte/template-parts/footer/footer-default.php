<?php
$copyright_btn_switcher = cs_get_option('footer_copyright_enable');
$copyright_text = cs_get_option('copyright_text');
$footer_item_list = cs_get_option('footer_item_list');

?>
<!-- Footer Section Start  -->
<section class="nbv2_footer nb-bg2 nb-mp nb-malls">
    <div class="nbv2_footer_wrapper">
        <div class="container">
            <div class="nbv2_footer_wrapper_container">
                <div class="nbv2_footer_top nb-ptb120">
                    <div class="row">
                        <?php if (is_active_sidebar('nestbyte_about_widget')) { ?>
                            <div class="col-12 col-lg-12 col-xl-3 col-xxl-3 col-md-6 col-sm-12 ps-0 has_fade_anim">
                                <?php dynamic_sidebar('nestbyte_about_widget'); ?>
                            </div>
                        <?php } ?>
                        <?php if (is_active_sidebar('nestbyte_useful_link_one')) { ?>
                            <div class="col-0 col-lg-12 col-xl-1 col-xxl-1 col-md-0 col-sm-0 ps-0 d-md-none d-sm-none d-lg-block d-xl-block  d-xxl-block"></div>
                            <div class="col-12 col-lg-12 col-xl-2 col-xxl-2 col-md-6 col-sm-12 nb-mtp has_fade_anim">
                                <?php dynamic_sidebar('nestbyte_useful_link_one'); ?>
                            </div>
                        <?php } ?>
                        <?php if (is_active_sidebar('nestbyte_useful_link_two')) { ?>
                            <div class="col-0 col-lg-12 col-xl-1 col-xxl-1 col-md-0 col-sm-0 ps-0 d-md-none d-sm-none d-lg-block d-xl-block  d-xxl-block"></div>
                            <div class="col-12 col-lg-2 col-xl-2 col-xxl-2 col-md-6 col-sm-12 nb-mtp has_fade_anim">
                                <?php dynamic_sidebar('nestbyte_useful_link_two'); ?>
                            </div>
                        <?php } ?>
                        <?php if (is_active_sidebar('nestbyte_recent_post')) { ?>
                            <div class="col-12 col-lg-12 col-xl-3 col-xxl-3 col-md-6 col-sm-12 nb-mtp has_fade_anim">
                                <?php dynamic_sidebar('nestbyte_recent_post'); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="nbv2_footer_bottom d-flex justify-content-between nb-ptb30 nb-dw nb-cr">
                    <?php if ($copyright_btn_switcher) { ?>
                        <p class="nb-f16 nb-fw4 nb-bcl nb-ffb"><?php echo wp_kses($copyright_text, true); ?></p>
                    <?php } ?>
                    <div class="nbv2_footer_bottom_link d-flex justify-content-between gap-3 nb-dw nb-ac">
                        <?php
                        if (is_array($footer_item_list)) {
                            foreach ($footer_item_list as $item) {
                                ?>
                                <a href="<?php echo esc_url($item['footer_list_link']['url']); ?>" class="nb_animation_text_link nb-f16 nb-fw4 nb-bcl nb-ffb"
                                   data-replace="Trams & Condition"> <span
                                            class="nb_animation_text_linksp"><?php echo esc_html($item['footer_list_text']); ?></span></a>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Footer Section End  -->