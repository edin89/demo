<?php
$id = is_home() ? get_option( 'page_for_posts' ) : get_the_ID();
$page_meta = get_post_meta($id, 'nestbyte_page_options' , true);

if ( !empty($page_meta) && $page_meta['global_page_meta'] == 'enabled' && !empty($page_meta['main-logo']['url'])){
    $main_logo = $page_meta['main-logo'];
}else{
    $main_logo = cs_get_option('main-logo');
}

$mobile_logo = cs_get_option('mobile-logo');
$header_phone_number_fieldset = cs_get_option('header_phone_number_fieldset');
$header_phone_svg_switcher = cs_get_option('header_phone_svg_switcher');

?>

<!-- Header Sction Start -->
<section class="nbv2_header nb-bg2 pt-3 pb-3 nb-malls" id="navbar">
    <div class="nbv2-container-nav nbv2_header_wrraper ">
        <div class="nbv2_header_wrraper_navbar">
            <div class="row align-items-center">
                <div class="col-lg-2 col-6">
                    <div class="logo-wrapper">
                        <?php if (is_array($main_logo) && !empty($main_logo['url'])) { ?>
                            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo mt-60 mb-20">
                                <img src="<?php echo esc_url($main_logo['url']); ?>" alt="logo" class="img-fluid">
                            </a>
                        <?php } else { ?>
                            <a href="<?php echo esc_url(home_url('/')); ?>">
                                <img src="<?php echo get_template_directory_uri() ?>/assets/images/logov2.svg" alt="logo" class="img-fluid">
                            </a>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-9 d-none d-lg-block">
                    <nav class="nb__navmenu text-center ps-xl-5 ul-li d-none d-lg-block">

                        <?php
                        if (has_nav_menu("main-menu")){
                            $replace_menu_class = str_replace('menu-item-has-children', 'has-submenu', wp_nav_menu(
                                    array(
                                        'theme_location' => 'main-menu',
                                        'echo' => false,
                                        'container' => '',
                                    )
                                )
                            );
                            $replace_menu_class = str_replace('sub-menu', 'submenu-wrapper', $replace_menu_class);

                            echo wp_kses_post($replace_menu_class);
                        }else{
                            echo '<ul><li><a href="' . esc_url(admin_url('nav-menus.php')) . '" >' . esc_attr('Add a menu', 'nestbyte') . '</a></li></ul>';
                        }

                        ?>
                    </nav>
                </div>
                <div class="nbv2_header_right  col-xl-3 col-lg-1 col-6">
                    <div class="nbv2_call_action_btn d-none d-lg-block d-xl-block d-xxl-block">
                        <a href="tel:+<?php if (is_array($header_phone_number_fieldset)) echo esc_attr($header_phone_number_fieldset['header_phone_number']) ?>" class="nb-f18 nb-fw7 nb-wcl nb-ffh text-end d-flex align-items-center justify-content-end header-right gap-3  nb-ahbr homeTwo__header-phone-number">
                            <?php if (is_array($header_phone_number_fieldset)) {
                                if ($header_phone_number_fieldset['header_phone_svg_switcher'] ) {
                                    if (is_array($header_phone_number_fieldset['header_phone_svg']) && !empty($header_phone_number_fieldset['header_phone_svg']['url']) ) {
                                        ?>
                                        <img src="<?php echo esc_url($header_phone_number_fieldset['header_phone_svg']['url']); ?>" alt="">
                                        <?php
                                    }
                                } else {
                                    if (!empty($header_phone_number_fieldset['header_phone_icon'])) {
                                        ?>
                                        <i class="<?php echo esc_attr($header_phone_number_fieldset['header_phone_icon']); ?>"></i>
                                        <?php
                                    }
                                }
                                if (!empty($header_phone_number_fieldset['header_phone_number'])) {
                                    ?>
                                    <span class="header__tel-number">+<?php echo esc_html($header_phone_number_fieldset['header_phone_number']); ?></span>
                                    <?php
                                }

                            }
                            ?>
                        </a>
                    </div>
                    <button type="button"
                            class="header-toggle mobile-menu-toggle d-block d-lg-none d-xl-none d-xxl-none">
                        <span class="offcanvas_border_one"></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!--mobile menu start-->
    <div class="mobile-menu ul-li">
        <a href="javascript:void(0)" class="close"><i class="isax icon-close-circle1"></i></a>

        <?php if (is_array($mobile_logo) && !empty($mobile_logo['url'])) { ?>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                <img src="<?php echo esc_url($mobile_logo['url']); ?>" alt="logo" class="logo">
            </a>
        <?php } else { ?>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                <img src="<?php echo get_template_directory_uri() ?>/assets/images/logov2.svg" alt="logo" class="img-fluid">
            </a>
        <?php } ?>
        <?php
        if (has_nav_menu("main-menu")){
            $replace_menu_class = str_replace('menu-item-has-children', 'has-submenu', wp_nav_menu(
                    array(
                        'theme_location' => 'main-menu',
                        'echo' => false,
                        'container' => '',
                        'menu_class' => 'mobile-nav-menu'
                    )
                )
            );
            $replace_menu_class = str_replace('sub-menu', 'submenu-wrapper', $replace_menu_class);
            echo wp_kses_post($replace_menu_class);
        }else{
            echo '<ul><li><a href="' . esc_url(admin_url('nav-menus.php')) . '" >' . esc_attr('Add a menu', 'nestbyte') . '</a></li></ul>';
        }

        ?>
    </div>
    <!--mobile menu end-->
</section>
<!-- Header Sction End -->