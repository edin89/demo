<?php

$id = is_home() ? get_option( 'page_for_posts' ) : get_the_ID();
$page_meta = get_post_meta($id, 'nestbyte_page_options' , true);
if ( !empty($page_meta) && $page_meta['global_page_meta'] == 'enabled'){
    if (isset($page_meta['main-logo']) && !empty($page_meta['main-logo']['url'])){
        $main_logo = $page_meta['main-logo'];
    }
}else{
    $main_logo = cs_get_option('main-logo');
}

$mobile_logo = cs_get_option('mobile-logo');
$top_header_on_off_switcher = cs_get_option('top_header_on_off_switcher');
$header_email_fieldset_home_two = cs_get_option('header_email_fieldset_home_two');
$header_location_fieldset_home_two = cs_get_option('header_location_fieldset_home_two');
$header_phone_number_fieldset_home_two = cs_get_option('header_phone_number_fieldset_home_two');
$home_two_header_social_repeater = cs_get_option('home_two_header_social_repeater');
$header_search_on_off_switcher = cs_get_option('header_search_on_off_switcher');
$header_offcanvas_on_off_switcher = cs_get_option('header_offcanvas_on_off_switcher');
$offcanvas_description = cs_get_option('offcanvas_description');
$offcanvas_gallery_img_group = cs_get_option('offcanvas_gallery_img_group');
$offcanvas_newsletter_title = cs_get_option('offcanvas_newsletter_title');
$offcanvas_newsletter_shortcode = cs_get_option('offcanvas_newsletter_shortcode');
?>
<!-- Header Start -->
<header>
    <?php if ($top_header_on_off_switcher) { ?>
        <div class="nb__top-header d-none d-xl-block">
            <div class="container">
                <div class="d-flex justify-content-between">
                    <?php if (is_array($header_email_fieldset_home_two) && !empty($header_email_fieldset_home_two['header_email_address'])) { ?>
                        <div class="nb__info-items d-flex align-items-center pera-content">
                            <a href="mailto:<?php echo esc_html($header_email_fieldset_home_two['header_email_address']); ?>" class="d-flex align-items-center">
                                <i class="<?php echo esc_attr($header_email_fieldset_home_two['header_email_icon']); ?> mr-10"></i>
                                <p><?php echo esc_html($header_email_fieldset_home_two['header_email_address']); ?> </p>
                            </a>
                        </div>
                    <?php } ?>
                    <?php if (is_array($header_location_fieldset_home_two) && !empty($header_location_fieldset_home_two['header_location_address'])) { ?>
                        <div class="nb__info-items d-flex align-items-center pera-content justify-content-center">
                            <i class="<?php echo esc_attr($header_location_fieldset_home_two['header_location_icon']); ?> mr-10"></i>
                            <p><?php echo esc_html($header_location_fieldset_home_two['header_location_address']); ?></p>
                        </div>
                    <?php } ?>
                    <?php if (is_array($header_phone_number_fieldset_home_two) && !empty($header_phone_number_fieldset_home_two['header_phone_number'])) { ?>
                        <div class="nb__info-items d-flex align-items-center pera-content  justify-content-center">
                            <a href="tel:<?php echo esc_html($header_phone_number_fieldset_home_two['header_phone_number']); ?>" class="d-flex align-items-center">
                                <i class="<?php echo esc_attr($header_phone_number_fieldset_home_two['header_phone_icon']); ?> mr-10"></i>
                                <p><?php echo esc_html($header_phone_number_fieldset_home_two['header_phone_number']); ?></p>
                            </a>
                        </div>
                    <?php } ?>
                    <?php if (is_array($home_two_header_social_repeater)) { ?>
                        <div class="nb__info-items d-flex align-items-center justify-content-end after-content-none nb__top-social-icon">
                            <?php foreach ($home_two_header_social_repeater as $list) { ?>
                                <a href="<?php echo esc_url($list['social_link']['url']); ?>"><i class="<?php echo esc_attr($list['social_icon']); ?>"></i></a>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="nb__main-header">
        <div class="container">
            <div class="row">
                <div class="col-6 col-lg-3">
                    <div class="nb__logo">
                        <?php if (is_array($main_logo) && !empty($main_logo['url'])) { ?>
                            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                                <img src="<?php echo esc_url($main_logo['url']); ?>" alt="logo">
                            </a>
                        <?php } else { ?>
                            <a href="<?php echo esc_url(home_url('/')); ?>">
                                <img src="<?php echo get_template_directory_uri() ?>/assets/images/balck_logo.svg" alt="logo">
                            </a>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-6 col-lg-9 d-flex align-items-center justify-content-end">
                    <nav class="nb__navmenu text-center ps-xl-5 ul-li d-none d-lg-block">
                        <?php
                        if (has_nav_menu("main-menu")) {
                            $replace_menu_class = str_replace('menu-item-has-children', 'has-submenu', wp_nav_menu(
                                    array(
                                        'theme_location' => 'main-menu',
                                        'echo' => false,
                                        'container' => '',
                                    )
                                )
                            );
                            $replace_menu_class = str_replace('sub-menu', 'submenu-wrapper', $replace_menu_class);
                            echo wp_kses_post($replace_menu_class);
                        }else{
                            echo '<ul><li><a href="' . esc_url(admin_url('nav-menus.php')) . '" >' . esc_attr('Add a menu', 'nestbyte') . '</a></li></ul>';
                        }
                        ?>
                    </nav>
                    <?php if ($header_search_on_off_switcher) { ?>
                        <div class="nb__header-search-form mr-45 ml-25 d-none d-sm-block">
                            <form class="nd__search" action="<?php echo home_url('/'); ?>" method="get">
                                <input type="text" id="search" class="search__input" placeholder="Search...." name="s" value="<?php the_search_query(); ?>"/>
                                <button type="button" class="search__button">
                                    <i class="nb_icon nb_icon-search"></i>
                                </button>
                            </form>
                        </div>
                    <?php } ?>
                    <?php if ($header_offcanvas_on_off_switcher) { ?>
                        <button type="button" class="header-toggle offcanvus-toggle d-lg-inline-flex d-none">
                            <span class="offcanvas_border_one"></span>
                            <span></span>
                        </button>
                    <?php } ?>
                    <button type="button" class="header-toggle mobile-menu-toggle d-lg-none">
                        <span class="offcanvas_border_one"></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Header End -->

<?php if ($header_offcanvas_on_off_switcher) { ?>
    <!--offcanvus start-->
    <div class="offcanvus-box position-fixed bg-white">
        <a href="javascript:void(0)" class="offcanvus-close"><i class="isax icon-close-circle1"></i></a>
        <div class="content-top">
            <?php if (is_array($main_logo) && !empty($main_logo['url'])) { ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="offcanvus-logo">
                    <img src="<?php echo esc_url($main_logo['url']); ?>" alt="logo">
                </a>
            <?php } else { ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="offcanvus-logo">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/images/balck_logo.svg" alt="logo">
                </a>
            <?php } ?>
            <?php if ($offcanvas_description) { ?>
                <p class="mb-0 mt-32 fw-light"><?php echo wp_kses($offcanvas_description, true); ?></p>
            <?php } ?>
        </div>
        <?php
        if (is_array($offcanvas_gallery_img_group)) { ?>
            <div class="offcanvus-gallery d-flex align-items-center flex-wrap">
                <?php foreach ($offcanvas_gallery_img_group as $gallery) { ?>
                    <a href="<?php echo esc_url($gallery['offcanvas_gallery_img_link']['url']); ?>"><img src="<?php echo esc_url($gallery['offcanvas_gallery_img']['url']); ?>" alt="not found"></a>
                <?php } ?>
            </div>
        <?php } ?>
        <div class="offcanvus-newsletter">
            <?php if (!empty($offcanvas_newsletter_title)) { ?>
                <h6 class="mb-4 text-center">Newsletter</h6>
            <?php } ?>
            <?php
                if ($offcanvas_newsletter_shortcode) {
                    echo do_shortcode($offcanvas_newsletter_shortcode);
                }
            ?>
        </div>

    </div>
    <!--offcanvus end-->
<?php } ?>
<!--mobile menu start-->
<div class="mobile-menu ul-li">
    <a href="javascript:void(0)" class="close"><i class="isax icon-close-circle1"></i></a>

    <?php if (is_array($mobile_logo) && !empty($mobile_logo['url'])) { ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
            <img src="<?php echo esc_url($mobile_logo['url']); ?>" alt="logo" class="logo">
        </a>
    <?php } else { ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
            <img src="<?php echo get_template_directory_uri() ?>/assets/images/logov2.svg" alt="logo" class="img-fluid">
        </a>
    <?php } ?>
    <?php
    if (has_nav_menu("main-menu")) {
        $replace_menu_class = str_replace('menu-item-has-children', 'has-submenu', wp_nav_menu(
                array(
                    'theme_location' => 'main-menu',
                    'echo' => false,
                    'container' => '',
                    'menu_class' => 'mobile-nav-menu'
                )
            )
        );
        $replace_menu_class = str_replace('sub-menu', 'submenu-wrapper', $replace_menu_class);
        echo wp_kses_post($replace_menu_class);
    }else{
        echo '<ul><li><a href="' . esc_url(admin_url('nav-menus.php')) . '" >' . esc_attr('Add a menu', 'nestbyte') . '</a></li></ul>';
    }
    ?>
</div>
<!--mobile menu end-->