<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Nestbyte
 */



?>
<div class="col-lg-4 col-xl-4 col-xxl-4 col-md-6 col-sm-12 has_fade_anim" data-delay=".5">
    <div class="nbv2_project_slide_single nbv2_project_main_single nb-iefmain m-0">
        <div class="nbv2_project_slide_content position-relative nb-ief ">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('project-thumb'); ?>
            <?php endif; ?>
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('project-thumb'); ?>
            <?php endif; ?>
            <div class="nbv2_project_slide_content_bottom_main position-absolute">
                <div class="nbv2_project_slide_content_bottom nbv2_project_arciv_content_bottom nb-bg2 position-relative m-auto">
                    <div class="slider_icon">
                        <i class="nb_icon  nb_icon-line nb-f37 nb-mcl nb-nb_icon-line"></i>
                    </div>
                    <p class="nb-f16 nb-fw4 nb-bcl nb-ffb text-capitalize">
                        <?php
                        echo get_the_term_list('', 'project-category', '', ' | ', '')
                        ?>
                    </p>
                    <h4 class="nb-f18 nb-fw7 nb-wcl nb-ffh text-capitalize">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h4>
                </div>
            </div>
        </div>
    </div>
</div>

