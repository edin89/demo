<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Nestbyte
 */
$service_cpt_tab[get_the_ID()] = get_the_ID();
$service_meta_icon = get_post_meta($service_cpt_tab[get_the_ID()], 'service_meta_icon', true);

?>
<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-4">
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <div class="nb__service-box nb__service-box-color nb-btna-hbr nb__service-box-arcive">
            <div class="nb__service-content">
                <div class="nb__service-title-with-icon">
                    <div class="nb__service-title nb__service-title-color">
                        <a href="<?php the_permalink(); ?>">   <?php the_title(); ?></a>
                    </div>
                    <div class="nb__service-icon nb__service-icon-color nb-btna">
                        <?php if (!empty($service_meta_icon)) { ?>
                            <i class="<?php echo esc_attr($service_meta_icon); ?>"></i>
                        <?php } ?>

                    </div>
                </div>
                <div class="nb__service-info pera-content nb__service-info-color">
                    <p><?php echo wp_trim_words(get_the_content(), 10); ?></p>
                </div>
            </div>
            <div class="nb__service-img">

                <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail(); ?>
                <?php endif; ?>
            </div>
        </div>
    </article>
</div>

