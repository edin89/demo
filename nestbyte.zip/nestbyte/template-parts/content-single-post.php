<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nestbute
 */

$title_hide_wd = cs_get_option('x_sbl_width_set');
$tag_list = get_the_tag_list('<ul><li>', '</li><li>', '</li></ul>');
$nl_author_id = get_the_author_meta('display_name');
$author_image = get_avatar(get_the_author_meta('ID'));
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';
$author_id = get_the_author_meta('ID');


if (is_active_sidebar('sidebar-1')) {
    $blog_column = 'col-12 col-lg-12 col-xl-8 col-xxl-8 col-md-12 col-sm-12';
    $sidebar_column = 'col-12 col-lg-12 col-xl-4 col-xxl-4 col-md-12 col-sm-12 mt-40 mt-md-0';
} else {
    $blog_column = 'col-8 col-xl-8 mx-auto';
    $sidebar_column = '';
}
//echo "<pre>";
//print_r($author_image);
//echo"</pre>";
?>

<!-- About Bredcrumb Start -->
<section class="nb_bredcrumb nb-bg1">
    <div class="nb_bredcrumb_wrapper">
        <div class="container">
            <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                <div class="nb_bredcrumb_left">
                    <div class="nb-about-contain">
                        <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                            <?php
                            //                                echo "<pre>";
                            //                                print_r(roots_title());
                            //                                echo"</pre>";
                            nestbyte_breadcrumbs_left();
                            ?>
                        </h4>
                    </div>
                </div>
                <div class="nb_bredcrumb_right">
                    <div>
                        <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                            <?php if (is_archive()) {
                                nestbyte_breadcrumbs();
                            } else {
                                ?>
                                <a href="#" class="nb-ahbr">Home</a>
                                <span>/</span>
                                <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                            <?php } ?>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="pt-150 pb-120 nb-bg1 nb__mobile-pt-100">
    <div class="container">
        <div class="row">
            <div class="<?php echo esc_attr($blog_column); ?>">
                <div>
                    <div class="mb-30 nb-admin-banner">
                        <?php the_post_thumbnail(); ?>
                    </div>
                    <div class="nb-admin-box-contain">
                        <h4>
                            <?php the_title(); ?>
                        </h4>
                        <ul class="nb-admin-box-ul">
                            <li>
                                <a href="<?php echo esc_url((get_author_posts_url($author_id))); ?>" class="nb-admin-box">
                                    <span>
                                      <?php echo wp_kses_post($author_image); ?>
                                    </span>
                                    <span class="nb_animation_text_link nb-f16 nb-fw4 nb-bcl nb-ffb "
                                          data-replace="By <?php echo esc_attr($nl_author_id); ?>">
                                        By <?php echo esc_html($nl_author_id); ?>
                                    </span>
                                </a>
                            </li>

                            <li class="d-flex gap-1">
                                <a href="#" class="nb-admin-box">
                                    <span class="nb-admin-box-icons">
                                        <i class="fa-solid fa-folder-open"></i>
                                    </span>
                                    <?php
                                    nestbute_post_cat_singl();
                                    ?>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="nb-admin-box">
                                    <span class="nb-admin-box-icons">
                                        <i class="fa-regular fa-comments"></i>
                                    </span>

                                    <span class="nb_animation_text_link nb-f16 nb-fw4 nb-bcl nb-ffb "
                                          data-replace="  <?php
                                          if (0 < get_comments_number()) {
                                              echo  ' comments ' .  get_comments_number() ;
                                          } else {
                                              echo   'comments ' . ( 0 );
                                          }
                                          ?>">
                                          <?php
                                          if ( ( 0 ) < get_comments_number()) {
                                              echo  ' comments ' .  get_comments_number() ;
                                          } else {
                                              echo   'comments ' . ( 0 );
                                          }
                                          ?>
                                    </span>
                                </a>
                            </li>
                        </ul>

                    </div>
                    <div class="nb-blog-info-contain nb-wcl">
                        <?php the_content(); ?>
                    </div>
                    <div class="nb-Category-link">
                        <?php nestbute_post_tag(); ?>
                        <ul class="nb-Category-link-ul-2 align-items-center">

                            <li class="nb-f18 nb-fw7 nb-wcl nb-ffh  pr-15">
                                Share:-
                            </li>

                            <?php nestbyte_single_blog_social_share(); ?>
                        </ul>
                    </div>
                    <div class="nb-blog-form-area">
                        <?php
                        // If comments are open or we have at least one comment, load up the comment template.
                        if (comments_open() || get_comments_number()) :
                            comments_template();
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <div class="<?php echo esc_attr($sidebar_column); ?> mt-40 mt-md-0">
                <!-- sidebar -->
                <?php if (is_active_sidebar('sidebar-1')) {
                    dynamic_sidebar('sidebar-1');
                } ?>
            </div>
        </div>
    </div>
</section>