<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Nestbyte
 */
$nl_author_id = get_the_author_meta( 'display_name' );
$author_id = get_the_author_meta('ID');
//echo "<pre>";
//print_r($nl_author_id);
//echo"</pre>";
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="nbv2_blog_single mb-70">
        <?php if (has_post_thumbnail()) { ?>
            <div class="nbv2_blog_single_mimg nb-iefmain">
                <div class="nbv2_blog_single_img position-relative nb-ief ">
                    <a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                        <?php
                        the_post_thumbnail();
                        the_post_thumbnail();
                        ?>
                    </a>
                </div>
            </div>
        <?php } ?>

        <div class="nbv2_blog_single_content pt-40 pb-40 pl-40 pr-40 nb-bg2" style="<?php if(has_post_thumbnail()){ ?> margin-top:  -76px; <?php }else{ ?> margin-top: 0px; <?php } ?>">
            
            <?php if (is_sticky()){ ?>
         <div class="ribbon" data-cursor-text="Featured" data-cursor="-color-accent-lilac">
  <span class="ribbon2"><i class="isax icon-star"></i></span>
</div>
<?php } ?>
            <div class="nbv2_blog_single_meta mb-25">
                <span class="nb_animation_title_main"> <?php nestbyte_posted_on(); ?></span>
                <span class="nb_animation_title_main"><a href="<?php echo esc_url((get_author_posts_url($author_id))); ?>" class="mb_name nb-f14 nb-fw4 nb-wcl nb-ffb nb-ahbr"> <?php   echo __('by', 'nestbyte');  ?> <span class="ml-1"><?php echo esc_html($nl_author_id); ?></span> <?php  ?> </a></span>
                <?php

                ?>
                <span class="nb_animation_title_main"><a href="#" class="mb_name nb-f18 nb-f14 nb-fw4 nb-wcl nb-ffb nb-ahbr"> <?php
                        if (0 < get_comments_number()) {
                            echo get_comments_number() . ' comments';
                        } else {
                            echo 0 . ' comment';
                        }
                        ?> </a></span>
            </div>

                <div class="nbv2_blog_single_title">
                    <h2>
                        <a href="<?php the_permalink(); ?>" class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh nb_animation_title_main nb-htcl mb-25">
                            <span class="nb_animation_title_main_non">  <?php the_title(); ?> </span>
                            <span class="nb_animation_title_main_hbr">  <?php the_title(); ?> </span>
                        </a>
                    </h2>
                </div>

            <p class="mb_name nb-f16 nb-fw4 nb-bcl nb-ffb"> <?php echo wp_trim_words(get_the_excerpt(), 50, '...'); ?>
            </p>
            <div class="nbv2_blog_single_button position-relative ">
                <a href="<?php the_permalink(); ?>" class="position-absolute nb_btn_hover_all "><i class=" isax icon-arrow-right1"></i></a>
            </div>
        </div>
    </div>

</article><!-- #post-<?php the_ID(); ?> -->
