<?php
/**
 * Theme Breadcrumbs
 *
 *  @package mayosis
 */
/**
 * Breadcrumbs
 *
 * Echoes the current breadcrumbs. Supports EDD built in taxs.
 *
 * @return   string
 * @access   private
 * @since    1.0
 */
/*=============================================
=            BREADCRUMBS			            =
=============================================*/

//  to include in functions.php

/*
*
*/
if ( ! function_exists( 'nestbyte_breadcrumbs' ) ) {
    function nestbyte_breadcrumbs() {
        global $wp_query, $post, $paged;
        $space      = ' ';
        $on_front   = get_option( 'show_on_front' );
        $blog_page  = get_option( 'page_for_posts' );
        $separator  = $space . '<span class="bredcrumb-separator"> / </span>' . $space;
        $link       = apply_filters( 'dm_breadcrumb_link', '<a href="%1$s" title="%2$s" rel="bookmark" class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end nb-ahbr">%2$s</a>' );
        $current    = apply_filters( 'dm_breadcrumb_current', '<span class="mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end nb-ahbr">%s</span>' );
        if ( ( $on_front == 'page' && is_front_page() ) || ( $on_front == 'posts' && is_home() ) ) {
            return;
        }
        $out = '<div class="breadcrumb breadcrumb-text fw-light mb-0 nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh gap-1">';
        if ( $on_front == "page" && is_home() ) {
            $blog_title = isset( $blog_page ) ? get_the_title( $blog_page ) : __( 'Our Blog', 'nestbyte' );
            $out .= sprintf( $link, home_url(), __( 'Home', 'nestbyte' ) ) . $separator . sprintf( $current, $blog_title );
        } else {
            $out .= sprintf( $link, home_url(), __( 'Home', 'nestbyte' ) );
        }
        if ( is_singular() ) {
            if ( is_singular( 'post' ) && $blog_page > 0 ) {
                $out .= $separator . sprintf( $link, get_permalink( $blog_page ), esc_attr( get_the_title( $blog_page ) ) );
            }
            if ( $post->post_parent > 0 ) {
                if ( isset( $post->ancestors ) ) {
                    if ( is_array( $post->ancestors ) )
                        $ancestors = array_values( $post->ancestors );
                    else
                        $ancestors = array( $post->ancestors );
                } else {
                    $ancestors = array( $post->post_parent );
                }
                foreach ( array_reverse( $ancestors ) as $key => $value ) {
                    $out .= $separator . sprintf( $link, get_permalink( $value ), esc_attr( get_the_title( $value ) ) );
                }
            }
            $post_type = get_post_type();
            if ( get_post_type_archive_link( $post_type ) ) {
                $post_type_obj = get_post_type_object( $post_type );
                $out .= $separator . sprintf( $link, get_post_type_archive_link( $post_type ), esc_attr( $post_type_obj->labels->menu_name ) );
            }
            $out .= $separator . sprintf( $current, get_the_title() );
        } else {
            if ( is_post_type_archive() ) {
                $post_type = get_post_type();
                $post_type_obj = get_post_type_object( $post_type );
                $out .= $separator . sprintf( $current, $post_type_obj->labels->menu_name );
            } else if ( is_tax() ) {
                if ( is_tax( 'download_tag' ) || is_tax( 'download_category' ) ) {
                    $post_type = get_post_type();
                    $post_type_obj = get_post_type_object( $post_type );
                    $out .= $separator . sprintf( $link, get_post_type_archive_link( $post_type ), esc_attr( $post_type_obj->labels->menu_name ) );
                }
                $out .= $separator . sprintf( $current, $wp_query->queried_object->name );
            } else if ( is_category() ) {
                $out .= $separator . __( '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">Category</span> <span class="bredcrumb-separator nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh">/</span> ', 'nestbyte' ) . sprintf( $current, $wp_query->queried_object->name );
            } else if ( is_tag() ) {
                $out .= $separator . __( '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">Tag</span> <span class="bredcrumb-separator nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh">/</span> ', 'nestbyte' ) . sprintf( $current, $wp_query->queried_object->name );

            } else if ( is_author() ) {

                $out .= $separator . __( '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">Author</span>', 'nestbyte' );
            } else if ( is_date() ) {
                $out .= $separator;
                if ( is_day() ) {
                    global $wp_locale;
                    $out .=  __( '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">Day</span>','nestbyte');
                    $out .= $separator . sprintf( $current, get_the_date() );
                } else if ( is_month() ) {
                    $out .= sprintf( $current, single_month_title( ' ', false ) );
                } else if ( is_year() ) {
                    $out .= sprintf( $current, get_query_var( 'year' ) );
                }
            } else if ( is_404() ) {
                $out .= $separator . sprintf( $current, __( 'Error 404', 'nestbyte' ) );
            } elseif ( is_search() ) {
                if (have_posts()) {
                    if ($show_home_link && $show_current) echo  '<span class="sep">' . $sep . '</span>';
                    if ($show_current) echo '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">' . $before . '</span>'. sprintf($text['search'], get_search_query()) . $after;
                } else {
                    if ($show_home_link) echo '<span class="sep">' . $sep . '</span>';
                    echo '<span class=" nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh nb-ahbr">' . $before . '</span>'. sprintf($text['search'], get_search_query()) . $after;
                }
            }
        }
        $out .= '</div>';
        echo apply_filters( 'nestbyte_breadcrumbs_out', $out );
    }
}
// Hooks into the Digital Store theme
add_action( 'nestbyte_before_template_header', 'nestbyte_breadcrumbs' );