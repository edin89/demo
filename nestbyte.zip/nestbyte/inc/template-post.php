<?php
if ( ! function_exists( 'nestbyte_post_style_list_sidebar' ) ) {
    function nestbyte_post_style_list_sidebar() { ?>

        <div class="nbv2_widget_rl_post d-flex align-items-cente mb-4 gap-3 nb-icon">
            <div class="nbv2_widget_rl_post_img">
                <a href="<?php the_permalink();?>" class="position-relative d-flex align-items-center justify-content-center  "> <?php if ( has_post_thumbnail() ) {
                        the_post_thumbnail();
                    } ?> <i class="isax icon-arrow-right1 position-absolute nb-wcl "></i></a>
            </div>
            <div class="nbv2_footer_rl_post_content">
                <a href="<?php the_permalink();?>" class="nb-f18 nb-fw7 nb-wcl nb-ffb nb_animation_title_main">
                    <span class="nb_animation_title_main_non text-capitalize">  <?php echo nestbyte_title_trim($maxchar= 38); ?> </span>
                    <span class="nb_animation_title_main_hbr text-capitalize"> <?php echo nestbyte_title_trim($maxchar= 38); ?> </span>
                </a>
                <p class="nb-f14 nb-fw4 nb-bcl nb-ffb nb-ahbr"> <?php nestbyte_posted_on(); ?></p>
            </div>
        </div>
    <?php } }