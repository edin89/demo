<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Nestbyte
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */

#-----------------------------------------------------------------#
# Theme Option Compatibility
#-----------------------------------------------------------------#/
if (class_exists('Nestbyte_Core')) {

    function cs_get_option($option, $name = NULL, $default = NULL) {
        $base_options = get_option('nestbyte_options');

        if ($name == NULL) {

            if (isset($base_options[$option])) {
                return $base_options[$option];
            } else {
                return false;
            }

        } else if (isset($base_options[$option][$name])) {

            return $base_options[$option][$name];

        } else if ($default != NULL) {

            return $default;

        } else {

            return false;

        }
    }


} else {
    function cs_get_option($option_name = '', $default = '') {
        return false;
    }

}

/*  Register Fonts  */
function nestbyte_fonts_url() {
    $fonts_url = '';

    /* Translators: If there are characters in your language that are not
    * supported by Lora, translate this to 'off'. Do not translate
    * into your own language.
    */
    $rajdhani = _x('on', 'Rajdhani font: on or off', 'nestbyte');

    /* Translators: If there are characters in your language that are not
    * supported by Rubik, translate this to 'off'. Do not translate
    * into your own language.
    */
    $rubik = _x('on', 'Rubik font: on or off', 'nestbyte');

    if ('off' !== $rajdhani || 'off' !== $rubik) {
        $font_families = array();

        if ('off' !== $rajdhani) {
            $font_families[] = 'Rajdhani:400,500,600,700';
        }

        if ('off' !== $rubik) {
            $font_families[] = 'Rubik:400,500,600';
        }

        $query_args = array(
            'family' => urlencode(implode('|', $font_families)),
            'subset' => urlencode('latin,latin-ext'),
        );

        $fonts_url = add_query_arg($query_args, 'https://fonts.googleapis.com/css');
    }

    return esc_url_raw($fonts_url);
}

function nestbyte_body_classes($classes) {
    // Adds a class of hfeed to non-singular pages.
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }

    // Adds a class of no-sidebar when there is no sidebar present.
    if (!is_active_sidebar('sidebar-1')) {
        $classes[] = 'no-sidebar';
    }

    return $classes;
}

add_filter('body_class', 'nestbyte_body_classes');

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function nestbyte_pingback_header() {
    if (is_singular() && pings_open()) {
        printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
    }
}

add_action('wp_head', 'nestbyte_pingback_header');

#-----------------------------------------------------------------#
# nestbyte Header Builder Start
#-----------------------------------------------------------------#/

if (!function_exists('nestbyte_header_builder')) {
    function nestbyte_header_builder() {

        $page_meta = get_post_meta(get_the_ID(), 'nestbyte_page_options', true);
        $custom_options = (!empty($page_meta['global_page_meta'])) ? $page_meta['global_page_meta'] : 'disabled';
        $header_style = '';
        if ($custom_options == 'enabled') {
            if ($page_meta['select_header_blocks_meta']) {
                $header = $page_meta['select_header_blocks_meta'];
            } else {
                $header_style = $page_meta['nestbyte-header-style'];
            }
        } else {
            $header_style = cs_get_option('nestbyte-header-style');
        }

        $stacked_header_enable = cs_get_option('stacked_header_enable');

        if (!empty($stacked_header_enable)) {
            $stackclass = 'stacked-header';
        } else {
            $stackclass = 'no-stacked-header';
        }
        if (!empty($header)) {
            echo '<header class="nestbyte-header-builder nestbyte-site-header ' . $stackclass . '"><div class="header-content-holder">' . \Elementor\Plugin::$instance->frontend->get_builder_content(intval($header)) . '</div></header>';
        } else {
            if ($header_style == 'style-two') {
                get_template_part('template-parts/header/header-style', 'two');
            } else {
                get_template_part('template-parts/header/header-style', 'one');
            }
        }
    }
}

#-----------------------------------------------------------------#
# Nestbyte Footer Builder
#-----------------------------------------------------------------#/

if (!function_exists('nestbyte_footer_builder')) {
    function nestbyte_footer_builder() {

        $page_meta = get_post_meta(get_the_ID(), 'nestbyte_page_options', true);
        $custom_options = (!empty($page_meta['global_page_meta'])) ? $page_meta['global_page_meta'] : 'disabled';
        $footer_style = '';
        if ($custom_options == 'enabled') {
            if ($page_meta['select_footer_blocks_meta']) {
                $footer = $page_meta['select_footer_blocks_meta'];
            } else {
                $footer_style = $page_meta['nestbyte-footer-style'];
            }
        } else {
            $footer_style = cs_get_option('nestbyte-footer-style');
        }

        if (!empty($footer)) {
            echo '<footer class="nestbyte-footer">' . \Elementor\Plugin::$instance->frontend->get_builder_content(intval($footer)) . '</footer>';
        } else {
            if ($footer_style == 'style-two') {
                get_template_part('template-parts/footer/footer', 'two');
            } else {
                get_template_part('template-parts/footer/footer', 'default');
            }
        }

    }

}

#-----------------------------------------------------------------#
# nestbyte Paginantion
#-----------------------------------------------------------------#/
if (!function_exists('nestbyte_page_navs')): /**
 * Displays post pagination links
 *
 * @since nestbyte 1.0
 */
    function nestbyte_page_navs($query = false) {
        global $wp_query;
        if ($query) {
            $temp_query = $wp_query;
            $wp_query = $query;
        }
        // Return early if there's only one page.
        if ($GLOBALS['wp_query']->max_num_pages < 2) {
            return;
        }
        ?>
        <!-- pagination -->
        <div class="page-numbers nb-page-numbers mt-105 ">
            <?php
            $big = 999999999; // need an unlikely integer
            echo paginate_links(array(
                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'format' => '?paged=%#%',
                'current' => max(1, get_query_var('paged')),
                'total' => $wp_query->max_num_pages,
                'type' => 'list',
                'prev_text' => '<i class="fa-solid fa-angle-left"></i>',
                'next_text' => '<i class="fa fa-angle-right"></i>'
            ));
            ?>
        </div>

        <?php
        if (isset($temp_query)) {
            $wp_query = $temp_query;
        }
    }
endif;


if (!function_exists('nestbyte_page_paging_nav')) {
    function nestbyte_page_paging_nav($max_num_pages = false, $args = array()) {

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        if ($max_num_pages === false) {
            global $wp_query;
            $max_num_pages = $wp_query->max_num_pages;
        }


        $defaults = array(
            'nav' => 'load',
            'posts_per_page' => get_option('posts_per_page'),
            'max_pages' => $max_num_pages,
            'post_type' => 'post',
        );


        $args = wp_parse_args($args, $defaults);

        if ($max_num_pages < 2) {
            return;
        }


        $big = 999999999; // need an unlikely integer

        $links = paginate_links(array(
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => $max_num_pages,
            'prev_next' => true,
            'prev_text' => esc_html__('Previous', 'nestbyte'),
            'next_text' => esc_html__('Next', 'nestbyte'),
            'end_size' => 1,
            'mid_size' => 2,
            'type' => 'list',
        ));

        if (!empty($links)): ?>
            <div class="nestbyte-common-paginav nestbyte-page-pagination flex text-center">
                <?php echo wp_kses_post($links); ?>
            </div>
            <div class="empty-space marg-sm-b60"></div>
        <?php endif;
    }


}

if (!function_exists('nestbyte_page_paging_nav')) {
    function nestbyte_page_paging_nav($max_num_pages = false, $args = array()) {

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        if ($max_num_pages === false) {
            global $wp_query;
            $max_num_pages = $wp_query->max_num_pages;
        }


        $defaults = array(
            'nav' => 'load',
            'posts_per_page' => get_option('posts_per_page'),
            'max_pages' => $max_num_pages,
            'post_type' => 'post',
        );


        $args = wp_parse_args($args, $defaults);

        if ($max_num_pages < 2) {
            return;
        }


        $big = 999999999; // need an unlikely integer

        $links = paginate_links(array(
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => $max_num_pages,
            'prev_next' => true,
            'prev_text' => esc_html__('Previous', 'nestbyte'),
            'next_text' => esc_html__('Next', 'nestbyte'),
            'end_size' => 1,
            'mid_size' => 2,
            'type' => 'list',
        ));

        if (!empty($links)): ?>
            <div class="page-numbers nb-page-numbers mt-105">
                <?php echo wp_kses_post($links); ?>
            </div>
            <div class="empty-space marg-sm-b60"></div>
        <?php endif;
    }
}
#-----------------------------------------------------------------#
# nestbyte Breadcrumbs For Left
#-----------------------------------------------------------------#/
function nestbyte_breadcrumbs_left() {
    if (is_home()) {
        if (get_option('page_for_posts', true)) {
            echo get_the_title(get_option('page_for_posts', true));
        } else {
            _e('Blog', 'nestbyte');
        }
    } elseif (is_archive()) {
        $term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
        if ($term) {
            echo esc_html($term->name);
        } elseif (is_post_type_archive()) {
            echo get_queried_object()->labels->name;
        } elseif (is_day()) {
            printf(__('Daily Archives: %s', 'nestbyte'), get_the_date());
        } elseif (is_month()) {
            printf(__('Monthly Archives: %s', 'nestbyte'), get_the_date('F Y'));
        } elseif (is_year()) {
            printf(__('Yearly Archives: %s', 'nestbyte'), get_the_date('Y'));
        } elseif (is_author()) {
            $author = get_queried_object();
            printf(__('Author Archives: %s', 'nestbyte'), $author->display_name);
        } else {
            single_cat_title();
        }
    } elseif (is_search()) {
        printf(__('Search Results for %s', 'nestbyte'), get_search_query());
    } elseif (is_404()) {
        _e('Not Found', 'nestbyte');
    } else {
        the_title();
    }
}

#-----------------------------------------------------------------#
# nestbyte Paginantion
#-----------------------------------------------------------------#/
if (!function_exists('nestbyte_page_navs')): /**
 * Displays post pagination links
 *
 * @since nestbyte 1.0
 */
    function nestbyte_page_navs($query = false) {
        global $wp_query;
        if ($query) {
            $temp_query = $wp_query;
            $wp_query = $query;
        }
        // Return early if there's only one page.
        if ($GLOBALS['wp_query']->max_num_pages < 2) {
            return;
        }
        ?>
        <!-- pagination -->
        <div class="page-numbers nb-page-numbers mt-105">
            <ul>
                <li><span class=" nb-f24 nb-fw7 nb-wcl nb-ffh nb-bg2 nb_btn_hover_all ">01</span></li>
                <li><a href="#" class=" nb-f24 nb-fw7 nb-wcl nb-ffh nb-bg2 nb_btn_hover_all ">02</a></li>
                <li><a href="#" class=" nb-f24 nb-fw7 nb-wcl nb-ffh nb-bg2 nb_btn_hover_all ">03</a></li>
                <li><a href="#" class=" nb-f24 nb-fw7 nb-wcl nb-ffh nb-bg2 nb_btn_hover_all "><i class="isax icon-arrow-right1"></i></a></li>
            </ul>
        </div>
        <div class="page-numbers nb-page-numbers mt-105">
            <?php
            $big = 999999999; // need an unlikely integer
            echo paginate_links(array(
                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'format' => '?paged=%#%',
                'current' => max(1, get_query_var('paged')),
                'total' => $wp_query->max_num_pages,
                'type' => 'list',
                'prev_text' => '<i class="fa-solid fa-angles-left"></i>',
                'next_text' => '<i class="fa-solid fa-angles-right"></i>'
            ));
            ?>
        </div>

        <?php
        if (isset($temp_query)) {
            $wp_query = $temp_query;
        }
    }
endif;


if (!function_exists('nestbyte_page_paging_nav')) {
    function nestbyte_page_paging_nav($max_num_pages = false, $args = array()) {

        if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        if ($max_num_pages === false) {
            global $wp_query;
            $max_num_pages = $wp_query->max_num_pages;
        }


        $defaults = array(
            'nav' => 'load',
            'posts_per_page' => get_option('posts_per_page'),
            'max_pages' => $max_num_pages,
            'post_type' => 'post',
        );


        $args = wp_parse_args($args, $defaults);

        if ($max_num_pages < 2) {
            return;
        }


        $big = 999999999; // need an unlikely integer

        $links = paginate_links(array(
            'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => $max_num_pages,
            'prev_next' => true,
            'prev_text' => esc_html__('Previous', 'nestbyte'),
            'next_text' => esc_html__('Next', 'nestbyte'),
            'end_size' => 1,
            'mid_size' => 2,
            'type' => 'list',
        ));

        if (!empty($links)): ?>
            <div class="page-numbers nb-page-numbers mt-105">
                <?php echo wp_kses_post($links); ?>
            </div>
            <div class="empty-space marg-sm-b60"></div>
        <?php endif;
    }


}
#-----------------------------------------------------------------#
# Title Trim
#-----------------------------------------------------------------#/
function nestbyte_title_trim($maxchar = 90) {

    $fullTitle = get_the_title();

    // get the length of the title
    $titleLength = strlen($fullTitle);

    if ($maxchar > $titleLength) {
        return $fullTitle;
    } else {
        $shortTitle = substr($fullTitle, 0, $maxchar);
        return $shortTitle . " &hellip;";
    }
}

#-----------------------------------------------------------------#
# Social Share
#-----------------------------------------------------------------#/
if (!function_exists('nestbyte_single_blog_social_share')) :
    function nestbyte_single_blog_social_share() {

        $dmsocialURL = urlencode(get_permalink());

        // Get current page title
        $dmsocialTitle = urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8'));


        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/share?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $dmsocialURL;
        $googleURL = 'https://plus.google.com/share?url=' . $dmsocialURL;
        $bufferURL = 'https://bufferapp.com/add?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
        $whatsappURL = 'whatsapp://send?text=' . $dmsocialTitle . ' ' . $dmsocialURL;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $dmsocialURL . '&amp;title=' . $dmsocialTitle;

        // Based on popular demand added Pinterest too
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url=' . $dmsocialURL . '&amp;description=' . $dmsocialTitle;


        echo '<li class="nb-btna-hbr"><a href="' . $facebookURL . '" target="_blank" class="nb-Category-link-icons nb-btna facebook "><i class="nb_icon nb_icon-facebook"></i></a></li>';
        echo '<li class="nb-btna-hbr"><a href="' . $twitterURL . '" target="_blank" class="nb-Category-link-icons nb-btna twitter"><i class="nb_icon nb_icon-twitter"></i></a></li>';
        echo '<li class="nb-btna-hbr"><a href="' . $linkedInURL . '" target="_blank" class="nb-Category-link-icons nb-btna linkedin"><i class="nb_icon nb_icon-instagram"></i></a></li>';


    }

    ;
endif;

#-----------------------------------------------------------------#
# Nestbyte get Custom Post type id
#-----------------------------------------------------------------#/
function nestbyte_get_cpt_id($post_type = '', $posts_per_page = 3, $order = 'DESC', $orderby = 'title') {
    $args = array(
        'post_type' => $post_type,
        'posts_per_page' => $posts_per_page,
        'order' => $order,
        'orderby' => $orderby,
    );

    $query = new WP_Query($args);
    $cpt_id = [];
    if ($query->have_posts()) {

        while ($query->have_posts()) {
            $query->the_post();
            $cpt_id[get_the_ID()] = get_the_ID();
        }
        wp_reset_postdata();
    }
    return $cpt_id;
}


if(!function_exists('nestbyte__wp_kses')):
	/**
	 * Allow basic tags
	 *
	 * @since 1.0.0
	 **/
	function nestbyte__wp_kses($string = '')
	{
		return wp_kses($string, [
			'a' => [
				'class' => [],
				'href' => [],
				'target' => []
			],
			'code' => [
				'class' => []
			],
			'strong' => [],
			'br' => [],
			'em' => [],
			'p' => [
				'class' => []
			],
			'span' => [
				'class' => []
			],
		]);
	}
endif;


if(!function_exists('nestbyte__implode_html_attributes')):
	/**
	 * Implode and escape HTML attributes for output.
	 *
	 * @since 1.9.4
	 * @param array $raw_attributes Attribute name value pairs.
	 * @return string
	 */
	function nestbyte__implode_html_attributes( $raw_attributes ) {

		$rendered_attributes = [];

		foreach ( $raw_attributes as $attribute_key => $attribute_values ) {
			if ( is_array( $attribute_values ) ) {
				$attribute_values = implode( ' ', $attribute_values );
			}

			$rendered_attributes[] = sprintf( '%1$s="%2$s"', $attribute_key, esc_attr( $attribute_values ) );
		}

		return implode( ' ', $rendered_attributes );
	}
endif;


if(!function_exists('nestbyte__valid_url')):
	/**
	 * Checks for valid 200 response code
	 *
	 * @since 2.4.0
	 **/
	function nestbyte__valid_url($url)
	{

		$response = wp_safe_remote_get( $url );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === wp_remote_retrieve_response_code( $response );
	}
endif;
