<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
function nestbyte_welcome_page() {
    require_once 'nestbyte-welcome.php';
}

function nestbyte_admin_menu() {
    if (current_user_can('edit_theme_options')) {
        add_menu_page('Nestbyte', 'Nestbyte', 'administrator', 'nestbyte-admin-menu', 'nestbyte_welcome_page', NESTBYTE_URL . '/assets/images/icon.svg', 4);
        add_submenu_page('nestbyte-admin-menu', 'nestbyte', esc_html__('Welcome', 'nestbyte'), 'administrator', 'nestbyte-admin-menu', 'nestbyte_welcome_page', 0);
        add_submenu_page('nestbyte-admin-menu', esc_html__('Demo Import', 'nestbyte'), esc_html__('Demo Import', 'nestbyte'), 'administrator', 'demo_install', 'nestbyte_demo_install_function');
    }
}

add_action('admin_menu', 'nestbyte_admin_menu');


function nestbyte_demo_install_function() {
    $url = admin_url() . 'admin.php?page=nestbyte-wizard&step=content';
    ?>
    <script>location.href = '<?php echo esc_html($url);?>'.replace(/\&amp\;/gi, "&");</script>
    <?php
}
