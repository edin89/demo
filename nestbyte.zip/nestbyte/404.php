<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Nestbyte
 */

get_header();
$arcive_img = cs_get_option('nl_bredcrumb_bg_image');
$arcive_card_img = is_array($arcive_img) && !empty($arcive_img['url']) ? $arcive_img['url'] : '';
?>

   <section class="nb_bredcrumb nb-bg1">
        <div class="nb_bredcrumb_wrapper">
            <div class="container">
                <div class="nb_bredcrumb_wrapper_container nb-dw justify-content-between">
                    <div class="nb_bredcrumb_left">
                        <div class="nb-about-contain">
                            <h4 class="mb_name nb-f32 nb-fw7 nb-wcl nb-ffh">
                                <?php
                                
                                nestbyte_breadcrumbs_left();
                                ?>
                            </h4>
                        </div>
                    </div>
                    <div class="nb_bredcrumb_right">
                        <div>
                            <h4 class="nb-about-contain-link mb_name nb-wcl nb-f24 nb-fw7  nb-ffh text-end ">
                                <?php if (is_archive()) {
                                    nestbyte_breadcrumbs();
                                } else {
                                    ?>
                                    <a href="#" class="nb-ahbr">Home</a>
                                    <span>/</span>
                                    <a href="#" class="nb-ahbr"><?php nestbyte_breadcrumbs_left(); ?></a>
                                <?php } ?>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
	<main id="primary" class="site-main nestbyte-404">

		<section class="nestbyte-error-404 not-found container">
		    <div class="row">
		        
		   
			<div class="page-header nestbyte-404-header col-12 col-md-6">
			    <img src="<?php echo get_template_directory_uri();?>/assets/images/404.svg" alt="404">
			
			</div><!-- .page-header -->

			<div class="page-content col-12 col-md-6">
			    	<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'nestbyte' ); ?></h1>
				<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'nestbyte' ); ?></p>

					<?php
					get_search_form();

					
					?>

			

			</div><!-- .page-content -->
			 </div>
		</section><!-- .error-404 -->

	</main><!-- #main -->

<?php
get_footer();
