<?php
/**
 * Nestbyte functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Nestbyte
 */

if (!defined('_S_VERSION')) {
    // Replace the version number of the theme on each release.
    define('_S_VERSION', '1.1');
}
#-----------------------------------------------------------------#
# Defined Constants
#-----------------------------------------------------------------#/
define('NESTBYTE_THEME_NAME', 'nestbyte');
if (!defined('NESTBYTE_PATH')) define('NESTBYTE_PATH', get_template_directory());
if (!defined('NESTBYTE_URL')) define('NESTBYTE_URL', get_template_directory_uri());
define('NESTBYTE_THEME_DIR', wp_normalize_path(NESTBYTE_PATH . '/'));
define('NESTBYTE_THEME_URI', preg_replace('/^http(s)?:/', '', NESTBYTE_URL) . '/');
define('NESTBYTE_CHILD_PATH', get_stylesheet_directory());
defined('NESTBYTE_USER_LOGGED') or define('NESTBYTE_USER_LOGGED', is_user_logged_in());

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function nestbyte_setup()
{
    /*
        * Make theme available for translation.
        * Translations can be filed in the /languages/ directory.
        * If you're building a theme based on Nestbyte, use a find and replace
        * to change 'nestbyte' to the name of your theme in all the template files.
        */
    load_theme_textdomain('nestbyte', get_template_directory() . '/languages');

    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    /*
        * Let WordPress manage the document title.
        * By adding theme support, we declare that this theme does not use a
        * hard-coded <title> tag in the document head, and expect WordPress to
        * provide it for us.
        */
    add_theme_support('title-tag');

    /*
        * Enable support for Post Thumbnails on posts and pages.
        *
        * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
        */
    add_theme_support('post-thumbnails');

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus(
        array(
            'main-menu' => esc_html__('Main menu', 'nestbyte'),
        )
    );

    /*
        * Switch default core markup for search form, comment form, and comments
        * to output valid HTML5.
        */
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    // Set up the WordPress core custom background feature.
    add_theme_support(
        'custom-background',
        apply_filters(
            'nestbyte_custom_background_args',
            array(
                'default-color' => 'ffffff',
                'default-image' => '',
            )
        )
    );

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');

    /**
     * Add support for core custom logo.
     *
     * @link https://codex.wordpress.org/Theme_Logo
     */
    add_theme_support(
        'custom-logo',
        array(
            'height' => 250,
            'width' => 250,
            'flex-width' => true,
            'flex-height' => true,
        )
    );

    add_image_size( 'service-widget-thumb', 410, 320, true );
    add_image_size( 'project-thumb', 410, 513, true );
    add_image_size( 'project-widget-thumb', 440, 305, true );
    add_image_size('nestbyte-blog-style-one-thumbnail', 300, 328, true);
}

add_action('after_setup_theme', 'nestbyte_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function nestbyte_content_width()
{
    $GLOBALS['content_width'] = apply_filters('nestbyte_content_width', 640);
}

add_action('after_setup_theme', 'nestbyte_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function nestbyte_widgets_init()
{
    register_sidebar(
        array(
            'name' => esc_html__('NestByte Sidebar', 'nestbyte'),
            'id' => 'sidebar-1',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h2 class="widget-title">',
            'after_title' => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('NestByte Service Sidebar', 'nestbyte'),
            'id' => 'service-sidebar-1',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h2 class="widget-title">',
            'after_title' => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte About Widget', 'nestbyte'),
            'id' => 'nestbyte_about_widget',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Useful Link One', 'nestbyte'),
            'id' => 'nestbyte_useful_link_one',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Useful Link Two', 'nestbyte'),
            'id' => 'nestbyte_useful_link_two',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Recent Post', 'nestbyte'),
            'id' => 'nestbyte_recent_post',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte About Widget Home Two', 'nestbyte'),
            'id' => 'nestbyte_about_widget_home_two',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Useful Link Home Two', 'nestbyte'),
            'id' => 'nestbyte_useful_link_home_two',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Useful Link Home Two Style Two', 'nestbyte'),
            'id' => 'nestbyte_useful_link_home_two_style_two',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
        )
    );
    register_sidebar(
        array(
            'name' => esc_html__('Nestbyte Social Icon Home Two', 'nestbyte'),
            'id' => 'nestbyte_social_icon_home_two',
            'description' => esc_html__('Add widgets here.', 'nestbyte'),
        )
    );
}

add_action('widgets_init', 'nestbyte_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function nestbyte_scripts()
{
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), _S_VERSION);
    wp_enqueue_style('theme_default', get_template_directory_uri() . '/assets/css/theme-default.css', array(), _S_VERSION);
    wp_enqueue_style('tabanimation', get_template_directory_uri() . '/assets/css/tabanimation.css', array(), _S_VERSION);
    wp_enqueue_style('fontawesome-all-min', get_template_directory_uri() . '/assets/css/all.min.css', array(), _S_VERSION);
    wp_enqueue_style('iconsax', get_template_directory_uri() . '/assets/css/iconsax-style.css', array(), _S_VERSION);
    wp_enqueue_style('iconly', get_template_directory_uri() . '/assets/css/iconly.css', array(), _S_VERSION);
    wp_enqueue_style('lity', get_template_directory_uri() . '/assets/css/lity.min.css', array(), _S_VERSION);
    wp_enqueue_style('custombox', get_template_directory_uri() . '/assets/css/custombox.min.css', array(), _S_VERSION);
    wp_enqueue_style('swiper-bundle', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), _S_VERSION);
    wp_enqueue_style('slick', get_template_directory_uri() . '/assets/css/slick.css', array(), _S_VERSION);
     wp_enqueue_style('customcursor', get_template_directory_uri() . '/assets/css/custom-cursor.min.css', array(), _S_VERSION);
    wp_enqueue_style('slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.css', array(), _S_VERSION);
    wp_enqueue_style('nestbyte-style', get_stylesheet_uri(), array(), _S_VERSION);
  
  
  wp_enqueue_style('nestbyte-google-fonts', nestbyte_fonts_url(), array(), null);
  
  
    wp_enqueue_style('main-style', get_template_directory_uri() . '/assets/css/style.css', array(), _S_VERSION);
    wp_enqueue_style('responsive-style', get_template_directory_uri() . '/assets/css/responsive.css', array(), _S_VERSION);
    wp_style_add_data('nestbyte-style', 'rtl', 'replace');

    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('nestbyte-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    wp_enqueue_script('lity', get_template_directory_uri() . '/assets/js/lity.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('count', get_template_directory_uri() . '/assets/js/count.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('gsap', get_template_directory_uri() . '/assets/js/gsap.min.js', array('jquery'), _S_VERSION, true);
  
    wp_enqueue_script('ScrollTrigger', get_template_directory_uri() . '/assets/js/ScrollTrigger.min.js', array('jquery'), _S_VERSION, true);
    
    wp_enqueue_script('locomotive-scroll', get_template_directory_uri() . '/assets/js/locomotive-scroll.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('SplitText', get_template_directory_uri() . '/assets/js/SplitText.min.js', array('jquery'), _S_VERSION, true);
    
    wp_enqueue_script('customcursor', get_template_directory_uri() . '/assets/js/custom-cursor.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('marquee', get_template_directory_uri() . '/assets/js/marquee.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('slick', get_template_directory_uri() . '/assets/js/slick.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('swiper-bundle', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('custombox', get_template_directory_uri() . '/assets/js/custombox.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('main-script', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('ThemeAnim', get_template_directory_uri() . '/assets/js/ThemeAnim.js', array('jquery'), _S_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}

add_action('wp_enqueue_scripts', 'nestbyte_scripts');

/**
 * Enqueue scripts and styles in admin panel.
 */
function nestbyte_register_admin_styles()
{
    wp_enqueue_style('nestbyte-admin-css', get_template_directory_uri() . '/assets/css/admin.css', array(), _S_VERSION);
    wp_enqueue_style('iconly', get_template_directory_uri() . '/assets/css/iconly.css', array(), _S_VERSION);
}

add_action('admin_enqueue_scripts', 'nestbyte_register_admin_styles');


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Functions For Widget post
 */
require get_template_directory() . '/inc/template-post.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
    require get_template_directory() . '/inc/jetpack.php';
}
/**
 * Breadcrumb.
 */
require get_template_directory() . '/inc/breadcrumb.php';
/**
 * Load WooCommerce compatibility file.
 */
if (class_exists('WooCommerce')) {
    require get_template_directory() . '/inc/woocommerce.php';
    require get_template_directory() . '/inc/vendor/woo-single-product-structure.php';
    
    
}
/**
 * Nestbyte Comments
 */
require get_template_directory() . '/inc/nestbyte_comment.php';

/**
 * Admin Page
 */
require get_template_directory() . '/inc/admin/admin.php';
require get_template_directory() . '/inc/admin/admin-init.php';

/**
 * Merlin Enqueue
 */
if (!is_customize_preview() && is_admin()) {

    require_once(get_template_directory() . '/inc/admin/merlin/vendor/autoload.php');
    require_once(get_template_directory() . '/inc/admin/merlin/class-merlin.php');
    require_once(get_template_directory() . '/inc/admin/merlin/merlin-config.php');
    require_once(get_template_directory() . '/inc/admin/merlin/merlin-filters.php');
}

/**
 * Remove contact form 7 auto p
 */
add_filter('wpcf7_autop_or_not', '__return_false');

/*
* Enable support for Post Thumbnails on posts and pages.
*
* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
*/
add_theme_support('post-thumbnails');


/*
* Smooth Scroll after loading issue fixed
*
* 
*/
add_action('wp_head', 'nestbyte_scroll_fixed');
function nestbyte_scroll_fixed(){
?>
 <script>history.scrollRestoration = "manual"</script>
<?php
};


